function authenticateUser(req, res, next) {
   const role = req.headers["x-user-role"];
   //means JavaScript is getting a value from the 
   // HTTP request headers and storing it in a variable called role.

   if (!(role == "Faculty")) {
       return res.status(403).send("Access denied.");
   }
   next();
}

module.exports = authenticateUser;
// EXPORT our functions so it can be use in other files.