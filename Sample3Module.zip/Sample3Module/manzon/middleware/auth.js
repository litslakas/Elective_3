function authenticateUser(req, res, next) {
    const role = req.headers["x-user-role"];

    if (role !== "Faculty") {
        return res.status(403).send("Forbidden");
    }

    next();
}

module.exports = authenticateUser;