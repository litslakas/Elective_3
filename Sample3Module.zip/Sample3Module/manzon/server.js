const express = require('express');
const app = express();
const port = 3443;

const logRequest = require('./middleware/logger');
const authenticateUser = require('./middleware/auth');
const errorHandler = require('./middleware/error');

app.use(express.json());

app.use(logRequest);

app.use(authenticateUser);

let students = [];

students.push({
    id: 1,
    name: 'John Doe',
    age: 20,
    course: 'Computer Science',
    email: 'johndoe@gmail.com',
    address: '123 Main St, Cityville',
});

app.get('/', (req, res) => {
   res.send(`<div>
    <h2> Welcome to Alibaba</h2>
    <h5>Welcome to our student management system.</h5>
   </div>`);
});

app.get('/about', (req, res) => {
    res.send('This is the about page.');
});

app.get('/contact', (req, res) => {
    res.send('This is the contact page.');
});



app.post('/students', authenticateUser, (req, res) => {
    students.push(req.body);
    res.json({ message: 'Student added successfully' });
});

app.put('/students/:id', authenticateUser, (req, res) => {
    const studentId = parseInt(req.params.id);
    const studentIndex = students.findIndex(student => student.id === studentId);
    if (studentIndex !== -1) {
        students[studentIndex] = { ...students[studentIndex], ...req.body };
        res.json({ message: 'Student updated successfully' });
    } else {
        res.status(404).json({ message: 'Student not found' });
    }
});

app.get('/students/:name', authenticateUser, (req, res) => {
    const studentname = req.params.name;
    const student = students.find(student => student.name === studentname);
    if (student) {
        res.json(student);
    } else {
        res.status(404).json({ message: 'Student not found' });
    }
});

app.delete('/students/:id', authenticateUser, (req, res) => {
    const studentId = parseInt(req.params.id);
    const studentIndex = students.findIndex(student => student.id === studentId);
    if (studentIndex !== -1) {
        students.splice(studentIndex, 1);
        res.json({ message: 'Student deleted successfully' });
    } else {
        res.status(404).json({ message: 'Student not found' });
    }
});


app.get('/students', authenticateUser, (req, res) => {
    res.json(students);
});

app.use(errorHandler);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});


